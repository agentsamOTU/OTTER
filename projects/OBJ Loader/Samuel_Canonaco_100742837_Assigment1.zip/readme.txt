The loading of the object is contained on lines 198-209 of main.cpp. The mesh loading is handled by my Mesh class. My orthographic setup is on line 290 of main.cpp. The rotation of the meshes is on line 350 and 351 of main.cpp. Lastly, by data should not be duplicated as I render the same VertexArrayObject twice, just with different transforms.

Samuel Canonaco 100742837